<?php

    namespace sa\app;
    
    use sa\app\ArraySort;

    class SortHorizontal extends ArraySort
    {        
        public function sortArrayType($sort, $array)
        {
            $array=$this->sortArray($sort, $array);   
            self::$sort_type1 = 'Horizontal  ' . $sort;
            return $array;
        }
    }